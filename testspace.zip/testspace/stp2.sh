echo "c1"
sudo ovs-appctl fdb/show c1
echo "c2"
sudo ovs-appctl fdb/show c2
echo "c3"
sudo ovs-appctl fdb/show c3
echo "c4"
sudo ovs-appctl fdb/show c4

echo "p1A1"
sudo ovs-appctl fdb/show p1A1
echo "p1A2"
sudo ovs-appctl fdb/show p1A2
echo "p2A1"
sudo ovs-appctl fdb/show p2A1
echo "p2A2"
sudo ovs-appctl fdb/show p2A2
echo "p3A1"
sudo ovs-appctl fdb/show p3A1
echo "p3A2"
sudo ovs-appctl fdb/show p3A2
echo "p4A1"
sudo ovs-appctl fdb/show p4A1
echo "p4A2"
sudo ovs-appctl fdb/show p4A2

echo "p1E1"
sudo ovs-appctl fdb/show p1E1
echo "p1E2"
sudo ovs-appctl fdb/show p1E2
echo "p2E1"
sudo ovs-appctl fdb/show p2E1
echo "p2E2"
sudo ovs-appctl fdb/show p2E2
echo "p3E1"
sudo ovs-appctl fdb/show p3E1
echo "p3E2"
sudo ovs-appctl fdb/show p3E2
echo "p4E1"
sudo ovs-appctl fdb/show p4E1
echo "p4E2"
sudo ovs-appctl fdb/show p4E2
