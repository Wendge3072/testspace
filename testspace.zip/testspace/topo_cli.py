from mininet.topo import Topo
class fatTree4_CLI(Topo):
    "Simple topology example."

    def build(self, mac_table_size=200):
        "Create custom topo."

        ## Core
        c1 = self.addSwitch('c1')
        c2 = self.addSwitch('c2')
        c3 = self.addSwitch('c3')
        c4 = self.addSwitch('c4')

        ## Aggregation
        pot1A1 = self.addSwitch('p1A1')
        pot1A2 = self.addSwitch('p1A2')
        pot2A1 = self.addSwitch('p2A1')
        pot2A2 = self.addSwitch('p2A2')
        pot3A1 = self.addSwitch('p3A1')
        pot3A2 = self.addSwitch('p3A2')
        pot4A1 = self.addSwitch('p4A1')
        pot4A2 = self.addSwitch('p4A2')

        ## Edge
        pot1E1 = self.addSwitch('p1E1')
        pot1E2 = self.addSwitch('p1E2')
        pot2E1 = self.addSwitch('p2E1')
        pot2E2 = self.addSwitch('p2E2')
        pot3E1 = self.addSwitch('p3E1')
        pot3E2 = self.addSwitch('p3E2')
        pot4E1 = self.addSwitch('p4E1')
        pot4E2 = self.addSwitch('p4E2')

        ## Hosts
        h1 = self.addHost('h1')
        h2 = self.addHost('h2')
        h3 = self.addHost('h3')
        h4 = self.addHost('h4')
        h5 = self.addHost('h5')
        h6 = self.addHost('h6')
        h7 = self.addHost('h7')
        h8 = self.addHost('h8')
        h9 = self.addHost('h9')
        h10 = self.addHost('h10')
        h11 = self.addHost('h11')
        h12 = self.addHost('h12')
        h13 = self.addHost('h13')
        h14 = self.addHost('h14')
        h15 = self.addHost('h15')
        h16 = self.addHost('h16')
        
        ## Links between Core and Aggregation
        self.addLink(c1, pot1A1)
        self.addLink(c1, pot2A1)
        self.addLink(c1, pot3A1)
        self.addLink(c1, pot4A1)
        self.addLink(c2, pot1A1)
        self.addLink(c2, pot2A1)
        self.addLink(c2, pot3A1)
        self.addLink(c2, pot4A1)
        self.addLink(c3, pot1A2)
        self.addLink(c3, pot2A2)
        self.addLink(c3, pot3A2)
        self.addLink(c3, pot4A2)
        self.addLink(c4, pot1A2)
        self.addLink(c4, pot2A2)
        self.addLink(c4, pot3A2)
        self.addLink(c4, pot4A2)

        ## Links between Aggregation and Edge
        self.addLink(pot1A1, pot1E1)
        self.addLink(pot1A1, pot1E2)
        self.addLink(pot1A2, pot1E1)
        self.addLink(pot1A2, pot1E2)
        self.addLink(pot2A1, pot2E1)
        self.addLink(pot2A1, pot2E2)
        self.addLink(pot2A2, pot2E1)
        self.addLink(pot2A2, pot2E2)
        self.addLink(pot3A1, pot3E1)
        self.addLink(pot3A1, pot3E2)
        self.addLink(pot3A2, pot3E1)
        self.addLink(pot3A2, pot3E2)
        self.addLink(pot4A1, pot4E1)
        self.addLink(pot4A1, pot4E2)
        self.addLink(pot4A2, pot4E1)
        self.addLink(pot4A2, pot4E2)

        ## Links between Edge and Hosts
        self.addLink(pot1E1, h1)
        self.addLink(pot1E1, h2)
        self.addLink(pot1E2, h3)
        self.addLink(pot1E2, h4)
        self.addLink(pot2E1, h5)
        self.addLink(pot2E1, h6)
        self.addLink(pot2E2, h7)
        self.addLink(pot2E2, h8)
        self.addLink(pot3E1, h9)
        self.addLink(pot3E1, h10)
        self.addLink(pot3E2, h11)
        self.addLink(pot3E2, h12)
        self.addLink(pot4E1, h13)
        self.addLink(pot4E1, h14)
        self.addLink(pot4E2, h15)
        self.addLink(pot4E2, h16)


topos = {'myfat' : (lambda : fatTree4_CLI())}