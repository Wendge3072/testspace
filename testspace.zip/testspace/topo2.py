from mininet.topo import Topo
from mininet.net import Mininet
from mininet.cli import CLI
from mininet.log import setLogLevel

class fatTree4(Topo):
    def build(self):
        ## Aggregation
        pot1A1 = self.addSwitch('p1A1')

        ## Edge
        pot1E1 = self.addSwitch('p1E1')
        pot1E2 = self.addSwitch('p1E2')

        ## Hosts
        h1 = self.addHost('h1')
        h2 = self.addHost('h2')
        h3 = self.addHost('h3')
        
        ## Links between Core and Aggregation

        ## Links between Aggregation and Edge
        self.addLink(pot1A1, pot1E1)
        self.addLink(pot1A1, pot1E2)

        ## Links between Edge and Hosts
        self.addLink(pot1E1, h1)
        self.addLink(pot1E1, h2)
        self.addLink(pot1E2, h3)

def run():
        topo = fatTree4()
        net = Mininet(topo)
        net.start()
        CLI(net)
        net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    run()