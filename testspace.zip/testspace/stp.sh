sudo ovs-vsctl set bridge c1 stp_enable=true
sudo ovs-vsctl set bridge c2 stp_enable=true
sudo ovs-vsctl set bridge c3 stp_enable=true
sudo ovs-vsctl set bridge c4 stp_enable=true

sudo ovs-vsctl set bridge p1A1 stp_enable=true
sudo ovs-vsctl set bridge p1A2 stp_enable=true
sudo ovs-vsctl set bridge p2A1 stp_enable=true
sudo ovs-vsctl set bridge p2A2 stp_enable=true
sudo ovs-vsctl set bridge p3A1 stp_enable=true
sudo ovs-vsctl set bridge p3A2 stp_enable=true
sudo ovs-vsctl set bridge p4A1 stp_enable=true
sudo ovs-vsctl set bridge p4A2 stp_enable=true

sudo ovs-vsctl set bridge p1E1 stp_enable=true
sudo ovs-vsctl set bridge p1E2 stp_enable=true
sudo ovs-vsctl set bridge p2E1 stp_enable=true
sudo ovs-vsctl set bridge p2E2 stp_enable=true
sudo ovs-vsctl set bridge p3E1 stp_enable=true
sudo ovs-vsctl set bridge p3E2 stp_enable=true
sudo ovs-vsctl set bridge p4E1 stp_enable=true
sudo ovs-vsctl set bridge p4E2 stp_enable=true

sudo ovs-vsctl del-fail-mode c1
sudo ovs-vsctl del-fail-mode c2
sudo ovs-vsctl del-fail-mode c3
sudo ovs-vsctl del-fail-mode c4

sudo ovs-vsctl del-fail-mode p1A1
sudo ovs-vsctl del-fail-mode p1A2
sudo ovs-vsctl del-fail-mode p2A1
sudo ovs-vsctl del-fail-mode p2A2
sudo ovs-vsctl del-fail-mode p3A1
sudo ovs-vsctl del-fail-mode p3A2
sudo ovs-vsctl del-fail-mode p4A1
sudo ovs-vsctl del-fail-mode p4A2

sudo ovs-vsctl del-fail-mode p1E1
sudo ovs-vsctl del-fail-mode p1E2
sudo ovs-vsctl del-fail-mode p2E1
sudo ovs-vsctl del-fail-mode p2E2
sudo ovs-vsctl del-fail-mode p3E1
sudo ovs-vsctl del-fail-mode p3E2
sudo ovs-vsctl del-fail-mode p4E1
sudo ovs-vsctl del-fail-mode p4E2